//1. TODO: call the init function when the html is loaded to add event listeners

// init adds event listeners.
function init(){
    // 2. TODO complete function init
    // add an event listener for all list items in the note-list
    // when clicked the function listClick should be run
}


// listClick displays the article belonging to a listNote
function listClick(){
    // if element has class showing, it is already displayed. No further action.
    if (this.classList.contains("showing")){
        return
    }

    // add class showing to display blue borde
    this.classList.add("showing");

    // extract the note_id from elements id
    var note_id = this.id.split("_")[1];

    // create article element with correct id
    var article = document.createElement("article");
    article.id = "article_"+ id;

    // 3.1 TODO:
    //     do an AJAX call to /note/<note_id> to retrieve the content of the article created above.
    // 3.2 TODO:
    //     add the content to the article and
    //     add the article as first child to the container div
}

// removeArticle removes an article from the dom and marks its listNote as not showing
function removeArticle(note_id){
    // 4.1 TODO:
    //     remove article with id article_{{note_id}} from the dom

    // 4.2 TODO:
    //     remove class "showing for note-list entry with id listNote_{{note_id}}    
}



