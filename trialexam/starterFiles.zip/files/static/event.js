
function CalenderItem(date, title, comment, imageUrl){
    this.date = date;
    this.title = title;
    this.comment = comment;
    this.imageUrl = imageUrl;
    this.daysLeft = function() {
        var now = new Date();
        return String(Math.floor((this.date - now) /86400000));
    }
}


