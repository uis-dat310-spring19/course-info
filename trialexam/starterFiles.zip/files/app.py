

from flask import Flask, request, render_template, redirect, url_for, flash, abort, session
from datetime import datetime
import json
from os import urandom

LOREM_IPSUM = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut leo turpis, vulputate quis volutpat porta, blandit vulputate mauris. Duis dapibus finibus tortor. Duis ante dolor, facilisis sed pellentesque id, blandit vehicula nunc. In hac habitasse platea dictumst. Pellentesque nunc lacus, pellentesque pharetra luctus at, egestas vitae mi. Aliquam semper ex id quam commodo fermentum. Morbi vulputate sapien et ante malesuada, quis viverra turpis interdum. Donec at dui sit amet nulla pulvinar dictum a sed lacus. Sed in pharetra leo. Sed dolor sapien, pellentesque hendrerit velit eu, aliquet tincidunt nibh. Cras hendrerit facilisis diam, nec imperdiet justo tristique in. Nunc aliquam semper ex, sit amet convallis leo convallis id. Curabitur vitae odio commodo, cursus ex egestas, tempor metus. Proin tincidunt sem ac egestas ornare. "


app = Flask(__name__)

@app.route("/")
def index():
    notes = [
        {
            "id": "1",
            "title":  "Meeting notes",
            "date": datetime(2019, 5, 1),
            "content": LOREM_IPSUM,
            "imageUrl": url_for("static", filename="images/meeting.png")
        },
        {
            "id": "2",
            "title":  "Reading notes",
            "date": datetime(2019, 4, 8),
            "content": LOREM_IPSUM,
            "imageUrl": url_for("static", filename="images/books.jpg")
        },
        {
            "id": "3",
            "title":  "Lecture notes",
            "date": datetime(2019, 5, 13),
            "content": LOREM_IPSUM,
            "imageUrl": url_for("static", filename="images/lecture.png")
        },

    ]

    for note in notes:
        note["fdate"] = formatDate(note["date"])

    return render_template("index.html", notes=notes)


def formatDate(date):
    return date.strftime("%d %B %Y")

@app.route("/post/<post_id>")
def getPost(post_id):
    posts = [
        {
            "id": "1",
            "title":  "Meeting notes",
            "date": datetime(2019, 5, 1),
            "content": LOREM_IPSUM,
            "imageUrl": url_for("static", filename="images/meeting.png")
        },
        {
            "id": "2",
            "title":  "Reading notes",
            "date": datetime(2019, 4, 8),
            "content": LOREM_IPSUM,
            "imageUrl": url_for("static", filename="images/books.jpg")
        },
        {
            "id": "3",
            "title":  "Lecture notes",
            "date": datetime(2019, 5, 13),
            "content": LOREM_IPSUM,
            "imageUrl": url_for("static", filename="images/lecture.png")
        },

    ]

    for post in posts:
        if post["id"] == post_id:
            post["fdate"] = formatDate(post["date"])
            return render_template("innerArticle.html", post=post)
    else:
        abort(404) # 404 Not Found

@app.route("/read")
def read():
    return redirect(url_for("index"))

@app.route("/add")
def add():
    '''
    TODO: Complete this function.
    1. On GET request return addForm.html template.
    2. On POST request 
        - check wether title, date and imageUrl are provided
        - create a dict with fields title, date, imageUrl, content
        - date should be a pythen datetime object
        - store the submitted new note in a session with a unique id field
        - change the function index above to also return note elements stored in the session
        - change the function getNote(note_id) above so that it can also retrieve notes from the session
    '''
    return render_template("addForm.html")
    

if __name__ == "__main__":
    app.run(debug=True)